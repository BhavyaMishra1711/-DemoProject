package com.example.demo.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.CourseDao;
import com.example.demo.entities.Course;

@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseDao coursedao;

	// List<Course> list;
	public CourseServiceImpl() {
		/*
		 * list=new ArrayList<>(); list.add(new
		 * Course(111,"Core Java","This has the basics of Java")); list.add(new
		 * Course(112,"Advance Java","This has advanced java")); list.add(new
		 * Course(113,"Complete Java","This has complete java tutorials"));
		 */

	}

	public List<Course> getCourses() {

		//return list;
		return coursedao.findAll();
		}

	@SuppressWarnings("deprecation")
	@Override
	public Course getCoursebyId(long courseId) {
		/*
		 * Course c=null; for(Course course:list)
		 *  { if(course.getId()==courseId) 
		 *  {
		 * c=course; break; } 
		 * }
		 *  return c;
		 */
		return coursedao.getById(courseId);
	}

	@Override
	public Course addCourse(Course course) {
		/*
		 * list.add(course); return course;
		 */
		coursedao.save(course);
		return course;
	}
}
